import {
  getLegalCases,
  addLegalCase,
} from "./database";

const LegalService = {

  getAll() {
    return getLegalCases();
  },

  create(caseData = {}) {

    const legalCase = {
      id: Date.now(),
      caseNumber: "CASE-" + Date.now(),
      title: caseData.title || "",
      clientName: caseData.clientName || "",
      advocateName: caseData.advocateName || "",
      courtName: caseData.courtName || "",
      status: caseData.status || "Pending",
      nextHearing: caseData.nextHearing || "",
      createdAt: new Date().toISOString(),
      ...caseData,
    };

    addLegalCase(legalCase);

    return legalCase;
  },

};

export default LegalService;