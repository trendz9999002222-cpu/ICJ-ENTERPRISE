import {
  getNotifications,
  addNotification,
} from "./database";

const NotificationService = {

  getAll() {
    return getNotifications();
  },

  create(notificationData = {}) {

    const notification = {
      id: Date.now(),
      title: notificationData.title || "",
      message: notificationData.message || "",
      type: notificationData.type || "Info",
      status: notificationData.status || "Unread",
      createdAt: new Date().toISOString(),
      ...notificationData,
    };

    addNotification(notification);

    return notification;
  },

  markAsRead(id) {

    const notifications = getNotifications();

    const notification = notifications.find(
      (item) => item.id === id
    );

    if (notification) {
      notification.status = "Read";
    }

    return notification;
  },

};

export default NotificationService;
