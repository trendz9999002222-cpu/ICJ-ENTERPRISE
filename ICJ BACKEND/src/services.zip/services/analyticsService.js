import {
  getMembers,
  getWallets,
  getTokens,
  getDonations,
  getLegalCases,
  getDocuments,
} from "./database";

const AnalyticsService = {

  getSummary() {

    return {

      members: getMembers().length,

      wallets: getWallets().length,

      tokens: getTokens().length,

      donations: getDonations().length,

      legalCases: getLegalCases().length,

      documents: getDocuments().length,

      generatedAt: new Date().toISOString(),

    };

  },

  getGrowth() {

    return {

      memberGrowth: 0,

      donationGrowth: 0,

      walletGrowth: 0,

      tokenGrowth: 0,

      legalGrowth: 0,

      documentGrowth: 0,

    };

  },

};

export default AnalyticsService;