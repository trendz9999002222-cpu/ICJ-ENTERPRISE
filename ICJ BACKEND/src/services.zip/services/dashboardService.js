import { getMembers } from "./database";
import { getWallets } from "./database";
import { getTokens } from "./database";
import { getDonations } from "./database";
import { getLegalCases } from "./database";
import { getDocuments } from "./database";

const DashboardService = {

  getStatistics() {

    return {

      totalMembers: getMembers().length,

      totalWallets: getWallets().length,

      totalTokens: getTokens().length,

      totalDonations: getDonations().length,

      totalLegalCases: getLegalCases().length,

      totalDocuments: getDocuments().length,

      lastUpdated: new Date().toISOString(),

    };

  },

};

export default DashboardService