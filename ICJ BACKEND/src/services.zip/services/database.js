// =====================================================
// ICJ Enterprise Platform
// In-Memory Database Foundation
// Version 1.0
// =====================================================

const Database = {
  members: [],
  wallets: [],
  communityTokens: [],
  donations: [],
  legalCases: [],
  documents: [],
  notifications: [],
  reports: [],
  settings: {},
  users: [],
  auditLogs: [],
};

export default Database;

// ===========================
// Member
// ===========================

export const getMembers = () => Database.members;

export const addMember = (member) => {
  Database.members.push(member);
};

export const updateMember = (id, data) => {
  const index = Database.members.findIndex((m) => m.id === id);

  if (index !== -1) {
    Database.members[index] = {
      ...Database.members[index],
      ...data,
    };
  }
};

export const deleteMember = (id) => {
  Database.members = Database.members.filter((m) => m.id !== id);
};

// ===========================
// Wallet
// ===========================

export const getWallets = () => Database.wallets;

export const addWallet = (wallet) => {
  Database.wallets.push(wallet);
};

// ===========================
// Token
// ===========================

export const getTokens = () => Database.communityTokens;

export const addToken = (token) => {
  Database.communityTokens.push(token);
};

// ===========================
// Donation
// ===========================

export const getDonations = () => Database.donations;

export const addDonation = (donation) => {
  Database.donations.push(donation);
};

// ===========================
// Legal
// ===========================

export const getLegalCases = () => Database.legalCases;

export const addLegalCase = (legalCase) => {
  Database.legalCases.push(legalCase);
};

// ===========================
// Documents
// ===========================

export const getDocuments = () => Database.documents;

export const addDocument = (document) => {
  Database.documents.push(document);
};

// ===========================
// Notifications
// ===========================

export const getNotifications = () => Database.notifications;

export const addNotification = (notification) => {
  Database.notifications.push(notification);
};

// ===========================
// Reports
// ===========================

export const getReports = () => Database.reports;

export const addReport = (report) => {
  Database.reports.push(report);
};