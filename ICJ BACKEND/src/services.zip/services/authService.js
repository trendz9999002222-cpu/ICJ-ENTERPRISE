const AuthService = {

  login(credentials = {}) {

    const user = {
      id: 1,
      name: credentials.name || "Administrator",
      email: credentials.email || "",
      role: credentials.role || "Admin",
      isAuthenticated: true,
      loginTime: new Date().toISOString(),
    };

    localStorage.setItem("icj_user", JSON.stringify(user));

    return user;
  },

  logout() {
    localStorage.removeItem("icj_user");
  },

  getCurrentUser() {
    const user = localStorage.getItem("icj_user");
    return user ? JSON.parse(user) : null;
  },

  isLoggedIn() {
    return localStorage.getItem("icj_user") !== null;
  },

};

export default AuthService;