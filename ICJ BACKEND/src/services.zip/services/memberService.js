import {
  getMembers,
  addMember,
  updateMember,
  deleteMember,
} from "./database";

export const MemberService = {

  getAll() {
    return getMembers();
  },

  create(member) {

    const year = new Date().getFullYear();

    const newMember = {
      id: Date.now(),

      memberId: ICJ-${year}-${Date.now()},

      registrationDate: new Date().toLocaleDateString(),

      createdAt: new Date().toISOString(),

      status: "Pending",

      membershipType: "General",

      walletBalance: 0,

      tokenBalance: 0,

      profilePhoto: "",

      documents: [],

      remarks: "",

      ...member,
    };

    addMember(newMember);

    return newMember;
  },

  update(id, data) {
    updateMember(id, data);
  },

  remove(id) {
    deleteMember(id);
  },

};