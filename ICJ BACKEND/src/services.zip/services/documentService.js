import {
  getDocuments,
  addDocument,
} from "./database";

const DocumentService = {

  getAll() {
    return getDocuments();
  },

  create(documentData = {}) {

    const document = {
      id: Date.now(),
      documentNo: "DOC-" + Date.now(),
      title: documentData.title || "",
      category: documentData.category || "",
      owner: documentData.owner || "",
      fileName: documentData.fileName || "",
      fileType: documentData.fileType || "",
      status: documentData.status || "Active",
      createdAt: new Date().toISOString(),
      ...documentData,
    };

    addDocument(document);

    return document;
  },

};

export default DocumentService;