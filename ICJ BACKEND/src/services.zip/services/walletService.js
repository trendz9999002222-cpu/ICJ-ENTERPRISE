import {
  getWallets,
  addWallet,
} from "./database";

export const WalletService = {

  getAll() {
    return getWallets();
  },

  create(memberId) {

    const wallet = {

      id: Date.now(),

      memberId,

      balance: 0,

      currency: "INR",

      status: "Active",

      createdAt: new Date().toISOString(),

    };

    addWallet(wallet);

    return wallet;

  },

};

export default WalletService;