import { getDonations, addDonation } from "./database";

const DonationService = {
  getAll() {
    return getDonations();
  },

  create(donationData = {}) {
    const donation = {
      id: Date.now(),
      receiptNo: "DON-" + Date.now(),
      amount: donationData.amount || 0,
      donorName: donationData.donorName || "",
      memberId: donationData.memberId || null,
      paymentMode: donationData.paymentMode || "Cash",
      status: "Received",
      createdAt: new Date().toISOString(),
      ...donationData,
    };

    addDonation(donation);
    return donation;
  },
};

export default DonationService;